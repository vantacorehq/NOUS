"""Split source into 'units of understanding' and fingerprint them.

A unit is the smallest chunk a human can honestly claim to understand:
a function, a method, the module-level remainder, or (for non-Python
languages) a block of code. Its identity is a hash of its normalized
text, so an attestation survives moves/renames but dies on any real edit.
"""
import ast
import hashlib
from dataclasses import dataclass

EXTS = {".py", ".js", ".jsx", ".ts", ".tsx", ".go", ".rs", ".java", ".kt", ".c", ".h",
        ".cc", ".cpp", ".hpp", ".cs", ".rb", ".php", ".swift", ".sh", ".sql", ".lua"}


def normalize(text: str) -> str:
    return "\n".join(l.rstrip() for l in text.splitlines() if l.strip())


@dataclass(frozen=True)
class Unit:
    path: str
    name: str
    start: int
    end: int
    text: str

    @property
    def id(self) -> str:
        return hashlib.sha256(normalize(self.text).encode()).hexdigest()[:16]

    @property
    def key(self) -> str:
        return f"{self.path}::{self.name}"

    @property
    def loc(self) -> int:
        return sum(1 for l in self.text.splitlines() if l.strip())


def split_python(path, src):
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return split_generic(path, src)
    lines = src.splitlines()
    defs = []

    def visit(body, prefix):
        for n in body:
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                s = min([n.lineno] + [d.lineno for d in n.decorator_list])
                defs.append((prefix + n.name, s, n.end_lineno))
            elif isinstance(n, ast.ClassDef):
                visit(n.body, prefix + n.name + ".")

    visit(tree.body, "")
    claimed, units = set(), []
    for name, s, e in defs:
        units.append(Unit(path, name, s, e, "\n".join(lines[s - 1:e])))
        claimed.update(range(s, e + 1))
    rest = [(i + 1, l) for i, l in enumerate(lines) if (i + 1) not in claimed and l.strip()]
    if rest:
        units.append(Unit(path, "<module>", rest[0][0], rest[-1][0], "\n".join(l for _, l in rest)))
    return units


def split_generic(path, src, min_loc=6):
    units, buf, start = [], [], 1
    lines = src.splitlines()

    def flush(end):
        nonlocal buf, start
        if buf:
            units.append(Unit(path, f"block@L{start}", start, end, "\n".join(buf)))
        buf = []

    for i, line in enumerate(lines, 1):
        if not buf and not line.strip():
            continue
        if not buf:
            start = i
        buf.append(line)
        if not line.strip() and sum(1 for l in buf if l.strip()) >= min_loc:
            flush(i)
    flush(len(lines))
    return units


def split(path, src):
    return split_python(path, src) if path.endswith(".py") else split_generic(path, src)
