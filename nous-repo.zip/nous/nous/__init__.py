"""NOUS — the ledger of human understanding."""
__version__ = "0.1.0"
